"""
oof_stacking.py - Shared helpers for leakage-safe stacked models
"""

from __future__ import annotations

import numpy as np


def run_sequential_oof(
    n_samples: int,
    n_outputs: int,
    splits,
    predictor_fn,
    fill_value: float = np.nan,
):
    """
    Run sequential out-of-fold predictions over precomputed time splits.

    predictor_fn signature:
        predictor_fn(train_idx, test_idx, fold_number) -> (predictions, fold_info)
    """
    out = np.full((n_samples, n_outputs), fill_value, dtype=np.float32)
    covered = np.zeros(n_samples, dtype=bool)
    reports = []

    for fold_no, (train_idx, test_idx) in enumerate(splits, start=1):
        preds, info = predictor_fn(train_idx, test_idx, fold_no)
        preds = np.asarray(preds, dtype=np.float32)
        if preds.shape != (len(test_idx), n_outputs):
            raise ValueError(
                f"OOF predictor returned {preds.shape}, expected {(len(test_idx), n_outputs)}"
            )
        out[test_idx] = preds
        covered[test_idx] = True
        info = info or {}
        info['fold'] = fold_no
        info['train_size'] = int(len(train_idx))
        info['test_size'] = int(len(test_idx))
        reports.append(info)

    return out, covered, reports


def fill_uncovered_probabilities(
    probs: np.ndarray,
    covered: np.ndarray,
    priors: np.ndarray | None = None,
) -> np.ndarray:
    out = np.asarray(probs, dtype=np.float32).copy()
    if priors is None:
        priors = np.ones(out.shape[1], dtype=np.float32) / max(out.shape[1], 1)
    priors = np.asarray(priors, dtype=np.float32).reshape(1, -1)
    out[~covered] = priors
    return out


def fill_uncovered_one_hot(
    one_hot: np.ndarray,
    covered: np.ndarray,
    default_class: int = 0,
) -> np.ndarray:
    out = np.asarray(one_hot, dtype=np.float32).copy()
    if out.shape[1] == 0:
        return out
    default_class = int(np.clip(default_class, 0, out.shape[1] - 1))
    out[~covered] = 0.0
    out[~covered, default_class] = 1.0
    return out
